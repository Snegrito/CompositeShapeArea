#ifndef SHAPE_H
#define SHAPE_H
#include "base-types.h"
#include <iostream>
#include <string>

class Shape {
public:
	virtual ~Shape() = default;
	virtual double getArea() const = 0;
	virtual rectangle_t getFrameRect() const = 0;
	virtual void move(const point_t& aim) = 0;
	virtual void move(double dx, double dy) = 0;
	virtual void scale(double scaleCoefficient) = 0;
	virtual const char* getName() const = 0;
	virtual Shape* clone() const = 0;
	bool operator<(const Shape& obj) {
		return this->getArea() < obj.getArea();
	}
    friend std::ostream& operator<<(std::ostream& out, const Shape * obj) {
		return out << obj->getArea() << " , " << obj->getName() << "\n";
	}
};

#endif 
